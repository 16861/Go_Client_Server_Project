extern int DasmZ80(char *buffer, int PC);

